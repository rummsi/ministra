<?php

namespace Ministra\Admin\Model;

class CertificatesModel extends \Ministra\Admin\Model\BaseMinistraModel
{
    public function __construct()
    {
        parent::__construct();
    }
}
