<?php

require_once '../../server/common.php';
use Ministra\Lib\R1f2236e0811d4596a67b2dcc907ac1cb\d3ef7751ac669db6e1e59b557a0ad1c15;
use Ministra\Lib\J581ea3eb83bdcf745728c0a6c2beb455\a5aa32303473177edf57ff69cb8882135\b0b972d045230fd3d29afe6e98deea32;
$server = new \Ministra\Lib\J581ea3eb83bdcf745728c0a6c2beb455\a5aa32303473177edf57ff69cb8882135\b0b972d045230fd3d29afe6e98deea32(new \Ministra\Lib\R1f2236e0811d4596a67b2dcc907ac1cb\d3ef7751ac669db6e1e59b557a0ad1c15());
$server->handleRequest();
