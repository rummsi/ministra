<?php

require_once '../server/common.php';
use Ministra\Lib\S642b6461e59cef199375bfb377c17a39\r84349e7571246cba7b331c0ae6ff19f2\c0bae98aeb47cb240f2c6cdd947c04ab;
(new \Ministra\Lib\S642b6461e59cef199375bfb377c17a39\r84349e7571246cba7b331c0ae6ff19f2\c0bae98aeb47cb240f2c6cdd947c04ab())->run();
