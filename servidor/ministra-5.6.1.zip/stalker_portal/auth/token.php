<?php

require_once __DIR__ . '/../server/common.php';
use Ministra\Lib\S642b6461e59cef199375bfb377c17a39\Z860a165ed018f157fd40ef2297209b46\t9da99a3480e53ad517ce33aca18b17c3;
use Ministra\Lib\R1f2236e0811d4596a67b2dcc907ac1cb\d3ef7751ac669db6e1e59b557a0ad1c15;
use Ministra\Lib\R1f2236e0811d4596a67b2dcc907ac1cb\dc4f44b5c48e5a029a85afdf5864d90a;
\Ministra\Lib\S642b6461e59cef199375bfb377c17a39\Z860a165ed018f157fd40ef2297209b46\t9da99a3480e53ad517ce33aca18b17c3::d5de025803f2de6a57d75fa98ac892b8c('Api v3 begin');
$oauth_server = new \Ministra\Lib\R1f2236e0811d4596a67b2dcc907ac1cb\dc4f44b5c48e5a029a85afdf5864d90a(new \Ministra\Lib\R1f2236e0811d4596a67b2dcc907ac1cb\d3ef7751ac669db6e1e59b557a0ad1c15());
$oauth_server->I5596fb73979e907463e2567e83a83f23();
